<template>
    <div>
        <mybtn @click="getList" icon="more" size="large" type="danger" >3s后关闭</mybtn>
        <mt-button @click="getList" icon="more" size="large" type="danger" >3s后关闭</mt-button>
    </div>
     
        
    
</template>

<script>
import {Toast} from 'mint-ui';

export default {
    data(){
        return{
            toastInstance:null
        }
    },
    methods:{
        getList(){
            setTimeout(()=>{
                this.toastInstance.close()
            },3000)
        },
        show(){
          this.toastInstance=Toast({
              message:'成功',
              position:'middle',
              duration:-1,
              iconClass:'glyphicon glyphicon-ok',
              className:'mytoast'
                });
        }
    },
    created(){
        this.show()
    }
}
</script>

<style>

</style>