import Vue from 'vue';

import VueRouter from 'vue-router';

Vue.use(VueRouter);

import 'bootstrap/dist/css/bootstrap.css'

import './app.css';

// import MintUI from 'mint-ui';

// import 'mint-ui/lib/style.css';

// Vue.use(MintUI);

//按需导入

import { Button } from 'mint-ui';

Vue.component(Button.name,Button);

import App from './App.vue'


const vm=new Vue({
    el:"#app",
    data:{

    },
    method:{

    },
    render:c=>c(App)
})
    
