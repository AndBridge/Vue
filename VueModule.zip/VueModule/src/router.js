        import Vue from 'vue';

        import VueRouter from 'vue-router';
        
        Vue.use(VueRouter);

        import account from './main/Account.vue';

        import goodlist from './main/goodList.vue';

        import login from './main/login.vue';

        import register from './main/register.vue';

        
        let router=new VueRouter({
            routes:[
                {path:"/account",component:account,children:[
                    {path:'login',component:login},
                    {path:'register',component:register}
                ]},
                {path:"/goodlist",component:goodlist}
            ]
        })

        export default router;