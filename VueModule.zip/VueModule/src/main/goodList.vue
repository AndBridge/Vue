<template>
    <div>
        <h1>This is a goodList</h1>
    </div>
</template>