<template>
    <div>
        <h2>This is a login</h2>
    </div>
</template>

<style scoped>
div{
    color: aqua;
}
</style>