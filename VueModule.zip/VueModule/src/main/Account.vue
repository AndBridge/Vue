<template>
    <div>
        <h1>This is a account</h1>
        <router-link to="/account/login">login</router-link>
        <router-link to="/account/register">register</router-link>
        <router-view></router-view>
    </div>
</template>

<style scoped>

div{
    background-color:red
}
/* 
样式作用域会遗传给子元素
 */
</style>