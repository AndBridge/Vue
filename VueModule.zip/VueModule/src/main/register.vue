<template>
    <div>
        <h1>This is a register</h1>
    </div>
</template>