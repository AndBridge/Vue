        import Vue from 'vue';

        import App from "./App.vue";

        import router from './router.js';

        const vm=new Vue({
            el:"#app",
            data:{

            },
            methods:{

            },
            render:c=>c(App),
            router
        })
        