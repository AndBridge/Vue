<template>
    <div>
        <h1>This is a APP module{{msg}}</h1>
        <router-link to="/account">account</router-link>
        <router-link to="/goodlist">goodlist</router-link>
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    data(){
        return{
            msg:'123'
        }
    }
}
</script>

<style lang="stylus" scoped>

</style>