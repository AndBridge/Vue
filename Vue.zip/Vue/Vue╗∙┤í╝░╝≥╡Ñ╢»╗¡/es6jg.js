let obj={
    name:"lili",
    age:18
}
let {name,age}=obj;
console.log(name);
console.log(age);
//变量对应


let objRename={
    name:"CoCo",
    age:20
}
let {name:n,age:years}=objRename;//变量对应
console.log(n);
console.log(years);

//解构对象
var objres={a:1,b:2};//变量对应
        function fun({a,b}){
            console.log("a:"+a);
            console.log("b:"+b);
        }
        fun(objres);
        //a:1
        //b:2
