const http=require("http");
const urlMethod=require('url');

const onRequest=(request,response)=>{
    response.writeHead(200,{"Content-Type":"application/json"});
    const pathname=urlMethod.parse(request.url,true).pathname;
    console.log(pathname);
    if(pathname==='/getscript' || pathname==='/'){
        var scriptStr='show()';
        response.end(scriptStr);
    }
}

const server=http.createServer(onRequest);

server.listen(3000,()=>{
    console.log('server listen at port 3000');
})