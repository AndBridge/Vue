        //复习在普通网页中使用：
        //1.引用包 2.创建一个div 3.创建vm实例

        // 如何在webPack构建的项目中使用Vue开发

        //import Vue from 'vue'; //这句导入的vue构造函数不完整，只提供了runtime-only方式

        /* 
        import Vue from 'vue'
         resolve: {
                        alias: {
                                "vue$": "vue/dist/vue.js"
                        }
                }
                这种我用不了
        1.找根目录有没有node_modules
        2.在node_modules中根据包名找对应的vue文件
        3.在vue文件中找package.json配置文件
        4.在package.json文件中,查找一个main属性【main属性指定了 这个包被加载的时候的入口文件】
        */

        //import Vue from '../node_modules/vue/dist/vue.js'
        import Vue from 'vue'
        import login from '../src/login.vue'
        //默认webpack无法打包，需要安装相关loader
        //在配置文件中新增配置项
        let vm = new Vue({
                el: "#app",
                data: {
                        msg: '123445'
                },
                methods: {

                },
              render(createElements){
                   return  createElements(login)
              }
        })