//回调函数
// function callFunction(fun,name){
// 	fun(name);
// }

// function sayHi(name){
// 	console.log(name + " Hi");
// }


// sayHi();



//callFunction(sayHi,'rails365');


function callFunction(fun,name){
	fun(name);
};



// callFunction(function(name){
// 	console.log(name+" Hi");
// },'rails365');






// (function (){
// 	console.log('ss')
// })()