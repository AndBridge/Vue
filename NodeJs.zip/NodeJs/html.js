var http=require("http");
var fs=require("fs");
function startServer(){

var onRequest=(request,response)=>{
	console.log("Request received");
	response.writeHead(200,{"Content-Type":"text/html"});
// 	var htmlfile="<!DOCTYPE html>"+
// "<html>"+
// 	"<head>"+
// 		"<meta charset=\"utf-8\">"+
// 		"<title>CSS过渡效果实现</title>"+
// 		"<style type=\"text/css\">"+
// 			"img{"+
// 				"width: 100%;"+
// 				"height: 100px;"+
// 			"}"+
// 			"html:hover img{"+
// 				"transition-delay: 100ms;"+
// 				"transition-duration: 2s;"+
// 				"width: 40%;height: 200px;"+
// 			"}"+
// 		"</style>"+
// 	"</head>"+
// 	"<body>"+
// 		"<img src=\""+__dirname+"\/c.jpg\" />"+
// 	"</body>"+
// "</html>"


var htmlfile=fs.createReadStream(__dirname+"/index.html","utf8");


	htmlfile.pipe(response)
}
var server=http.createServer(onRequest);
server.listen(3000,"127.0.0.1");
console.log("Server started on localhost port 3000");
	
}
module.exports.started=startServer;