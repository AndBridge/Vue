var http=require("http");
var fs=require("fs");


var onRequest=(request,response)=>{
	console.log(request.url);
	if(request.url==="/" || request.url==="/home"){
	response.writeHead(200,{"Content-Type":"text/html"});
	var ReadHtml=fs.createReadStream(__dirname+"/home.html","utf8");
	ReadHtml.pipe(response);
	}else if(request.url==="/review"){
		response.writeHead(200,{"Content-Type":"text/html"});
		var ReadHtml=fs.createReadStream(__dirname+"/review.html","utf8");
		ReadHtml.pipe(response);
	}else if(request.url==="/api/v1/records"){
		response.writeHead(200,{"Content-Type":"application/json"});
		var objson={
			name:"lili",
			age:18
		}
		
		// JSON.stringify(objson).pipe(response);错误的
		response.end(JSON.stringify(objson));
	}else{
		response.writeHead(200,{"Content-Type":"text/html"});
		var ReadHtml=fs.createReadStream(__dirname+"/404.html","utf8");
		ReadHtml.pipe(response);
	}
}
var server=http.createServer(onRequest);
server.listen(3000,"127.0.0.1");
console.log("Server started on localhost port 3000");