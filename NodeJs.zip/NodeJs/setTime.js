// var time=0;
// var tr=setInterval(()=>{
// 	time+=2;
// 	console.log(time + " seconds have passed");
// 	if(time>5){
// 		clearInterval(tr);
// 	}
// },2000);
console.log(__dirname);//输出当前目录位置（包括目录名）
console.log(__filename);//输出当前文件位置(包括文件名)