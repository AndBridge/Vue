var http=require("http");
var fs=require("fs");
var url=require("url");
var querystring=require("querystring")
function startRouter(routes,handle){
	
var onRequest=(request,response)=>{
	
	var pathname=url.parse(request.url).pathname;
	console.log("Request received"+pathname);
	
	// var data="";
	var data=[];
	request.on("error",function(err){
		console.error(err);
	}).on("data",function(chunk){
		// data +=chunk;
		data.push(chunk)
		console.log(data);
	}).on("end",function(){
		
		if(request.method==="POST"){
			if(data.length>1e6){
				request.connection.destroy();
			}
			data=Buffer.concat(data).toString();
		routes(handle,pathname,response,querystring.parse(data));
		}else{
			var params=url.parse(request.url,true).query;
			routes(handle,pathname,response,params);
		}
	})
	// if(request.url==="/" || request.url==="/home"){
	// response.writeHead(200,{"Content-Type":"text/html"});
	// var ReadHtml=fs.createReadStream(__dirname+"/home.html","utf8");
	// ReadHtml.pipe(response);
	// }else if(request.url==="/review"){
	// 	response.writeHead(200,{"Content-Type":"text/html"});
	// 	var ReadHtml=fs.createReadStream(__dirname+"/review.html","utf8");
	// 	ReadHtml.pipe(response);
	// }else if(request.url==="/api/v1/records"){
	// 	response.writeHead(200,{"Content-Type":"application/json"});
	// 	var objson={
	// 		name:"lili",
	// 		age:18
	// 	}
		
	// 	// JSON.stringify(objson).pipe(response);错误的
	// 	response.end(JSON.stringify(objson));
	// }else{
	// 	response.writeHead(200,{"Content-Type":"text/html"});
	// 	var ReadHtml=fs.createReadStream(__dirname+"/404.html","utf8");
	// 	ReadHtml.pipe(response);
	// }
}

var server=http.createServer(onRequest);
server.listen(3000,"127.0.0.1");
console.log("Server started on localhost port 3000");
}
module.exports.startRouter=startRouter;