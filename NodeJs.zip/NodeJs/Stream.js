//引入文件系统
var fs=require("fs");
//创建一个读的流 (输入流)
//***流也是也是事件的实例，所以也拥有一些事件的特性
//事件：EventEmitter util 触发:emit

//流读文件
// var myReadStream=fs.createReadStream(__dirname+"/readMe.txt","utf8");
var myReadStream=fs.createReadStream(__dirname+"/readMe.txt");
myReadStream.setEncoding("utf8");
// console.log(myReadStream);

//异步读文件
// fs.readFile("readMe.txt","utf8",(err,data)=>{
// 	console.log(data)
// })

// var data="";
// myReadStream.on("data",(funk)=>{
// 	console.log("new funk received");
// 	console.log(data+=funk);
// })
// myReadStream.on("end",()=>{
// 	console.log(data);
// })

//流写文件
var myWriteStream=fs.createWriteStream(__dirname+"/writeMe.txt");
// myReadStream.on("data",(funk)=>{
// 	console.log("11")
// 	myWriteStream.write(funk);
// })


// var writeData="你好呀";
// myWriteStream.write(writeData,"utf8");
// myWriteStream.end();
// myWriteStream.on("finish",function(){
// 	console.log("finished");
// })

//复制文件
myReadStream.pipe(myWriteStream);