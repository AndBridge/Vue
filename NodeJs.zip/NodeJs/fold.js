var fs=require("fs");


//异步删除文件
// fs.unlink("writeMe",function(){
// 	console.log("delete writeMe file");
// })
//同步删除文件
// fs.unlinkSync("writeMe");
//同步新建目录
//fs.mkdirSync("stuff");

//异步新建目录
// fs.mkdir("wrr",()=>{
// 	console.log("wrr make success");
// })

//异步删除目录
// fs.rmdir("wrr",()=>{
// 	console.log("wrr fold delete success");
// })

//同步删除目录
// fs.rmdirSync("stuff");

fs.mkdir("stuff",()=>{
	console.log("stuff mkdir successfully");
})

fs.readFile("readMe.txt","utf8",(err,data)=>{
	fs.writeFile("./stuff/writeMe.txt",data,()=>{
		console.log('copy successfully');
	})
})
