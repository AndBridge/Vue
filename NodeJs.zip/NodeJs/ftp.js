//引入http;
var http=require("http");
var url=require("url");
// var server=http.createServer((request,response)=>{
// 	console.log('Request received');
// 	//响应
// 	response.writeHead(200,{'Content-Type':'text/plain'});
// 	response.write("哈哈哈哈");
// 	response.end();
// })
// 	server.listen(3000,"127.0.0.1");
// 	console.log("server started on localhost port 3000");

function onRequest(request,response){
	console.log("Request received");
	response.writeHead(200,{"Content-Type":"text/plain"});
	response.end("Hello everyone");
	console.log(url.parse(request.url,true).query);//路由的参数
}
	var server=http.createServer(onRequest);

// var server=http.createServer((request,response)=>{
// 	console.log("Request received");
// 	response.writeHead(200,{"Content-Type":"text/plain"});
// 	response.end("Hello everyone");
// })
	server.listen(3000,"127.0.0.1");
	console.log("Server started on localhost port 3000");
