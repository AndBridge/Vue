var stuff=require('./count');
var pi=require('./count').pi;
console.log(stuff.counter(['ruby','nodejs','react']));
console.log(stuff.adder(1,2));

console.log(pi);