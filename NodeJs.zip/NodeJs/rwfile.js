// var fs=require('fs');
// var readMe=fs.readFileSync("readMe.txt","utf8");
// console.log(readMe);

// fs.writeFileSync("writeMe","hello world");
// var writeMe=fs.readFileSync("writeMe","utf8");
// console.log(writeMe)

// console.log("finised");

//异步
var fs=require("fs");
// var readMe=fs.readFile("readMe.txt","utf8",(err,data)=>{
// 	console.log(data);
// });

// var waitTill=new Date(new Date().getTime()+4*1000);
// while(waitTill>new Date()){}

// console.log("finished");

var writeY=fs.writeFile("writeMe","你，你好",()=>{
	
	console.log("writeY has finised");
});
 console.log("finished");