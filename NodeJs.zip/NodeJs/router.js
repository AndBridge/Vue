var fs=require("fs");
function router(handle,pathname,response,params){
	console.log("Routing a request for "+pathname);
	if(typeof handle[pathname]==='function'){
		handle[pathname](response,params);
	}else{
		response.writeHead(200,{"Content-Type":"text/html"});
		var ReadHtml=fs.createReadStream(__dirname+"/404.html","utf8");
		ReadHtml.pipe(response);
	}
}
module.exports.router=router;