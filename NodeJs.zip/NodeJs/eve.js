var events=require('events');
var util=require('util');

var Person=function(name,age){
	this.name=name;
	this.age=age;
} 
util.inherits(Person,events.EventEmitter);

var xiaoming=new Person('xiaoming',18);
var lili=new Person('lili',20);
var lucy=new Person('lucy',20);

var person=[xiaoming,lili,lucy];
console.log(person);
person.forEach(function(person){
	person.on('speak',function(message){
		console.log(person.name+"said:"+message+"  " +person.age);
	})
})
xiaoming.emit('speak','hi');


//var myEmitter=new events.EventEmitter();

// myEmitter.on('someEvent',function(message){
// 	console.log(message);
// })

// myEmitter.emit('someEvent','the event emitted');