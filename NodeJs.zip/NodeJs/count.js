function counter(arr){
	return "there are "+arr.length + " elements in the array";
}
// console.log(counter(['ruby','nodejs','react']));
function adder(a,b){
	return `the sum of the 2 numbers is ${a+b}`;
}
var pi=3.14;
//2
// module.exports={
// 	counter:counter,
// 	adder:adder,
// 	pi:pi
// }
//1
// module.exports.counter= counter;
// module.exports.adder= adder;
// module.exports.pi=pi;


//3
module.exports={
	counter:function counter(arr){
	return "there are "+arr.length + " elements in the array";
},
// console.log(counter(['ruby','nodejs','react']));
	adder:function adder(a,b){
	return `the sum of the 2 numbers is ${a+b}`;
},
	pi:pi=3.14

}
