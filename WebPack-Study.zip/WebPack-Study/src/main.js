    // main.js时我们项目的JS入口文件


    // 1.导入jq


    //浏览器require也不支持
    // const $=require('jquery');


    // import ... from ... 是es6中导入模块的方式

    // 由于es6语法太高级,浏览器解析不了所以这一行会报错
    
    import $ from 'jquery'
    // 这里的$和下面的$(function)的$对应
    

    // 导入样式表
    import './css/index.css'
    //webpack默认只能处理JS类型的文件，没法处理其他类型的文件
    // 如果要处理非JS类型的文件，需要手动安装一些合适的第三方loader加载器;
    // 1.如果想要打包处理CSS文件,需要安装npm i style-loader css-loader -D

    // 2.打开webpack.config.js配置文件，在里面新增一个配置节点
    // 叫做module，他是一个对象，在这个对象身上有个rules属性，这个rules属性是个数组
    // 这个数组中存放了所有第三方文件的匹配和处理规则
    

    // 导入less
    import './css/index.less'


    // 导入scss
    import './css/index.scss'



    // 导入bootstrap
    // 可以省略node_modules
    import '../node_modules/bootstrap/dist/css/bootstrap.css'
    $(function(){
        $('li:odd').css('backgroundColor','write')
        $('li:even').css('backgroundColor',function(){
            return '#'+'0000'
        })
    })


    // 1.webpack能处理js文件互相依赖的关系

    //2.webpack能处理JS的兼容问题,
    //把高级浏览器不识别的语法转化成正常浏览器能识别的语法

    //.\node_modules\.bin\webpack .\src\main -o .\dist\bundle.js


    //使用webpack-dev-server这个工具,来实现自动打包编译的功能

    // 1.运行npm i webpack-dev-server -D把这个工具安装到项目的本地开发依赖

    // 2.安装完毕后这个工具的用法和webpack命令的用法完全一样

    // webpack-dev-server帮我们打包生成的bundle,js文件并没有存放到实际的物理磁盘上
    // 而是直接托管到了电脑内存中，所以项目根目录中根本找不到这个打包好的bundle.js文件

    // 我们可以任务webpack-dev-server把打包好的文件以一种虚拟形式托管到了咱们项目目录中
    // 虽然看不见他，但是可以认为和dist src node_modules平级有一个看不见的文件叫做bundle.js


    // es6提供的新语法，用来实现es6中面向对象的开发方式
    // 这种写法和java C#实现面向对象完全一样了 class是从后端借鉴过来的
    class Person{
        // 使用static关键字可以定义静态属性
        // 静态属性,可以直接通过类名直接访问属性
        // 实例属性，只能通过类的实例访问的属性叫实例属性
        static info={name:'zs',age:20}
         pro={name:'ls',age:20}
    }
    // 实例属性
    var p1=new Person();
    console.log(p1.pro.name);

    // 静态属性
    console.log(Person.info.name);



    // 在webpack只能处理一部分es6新语法，一些更高级的es6和es7处理不了需要新的loader处理
    // 通过Babel可以转化
    // webpack种安装
    //1.1 npm install babel-loader@8.0.0-beta.0 @babel/core @babel/preset-env -D
    //1.2 npm install babel-plugin-transform-runtime --save-dev
    //1.3 npm install babel-runtime --save-dev
    //1.4 npm i @babel/plugin-proposal-class-properties -D
    // 2.打开webpack配置文件，在module节点下rules数组中添加一个新的规则：
    // {test:/\.js$/,use:"babel-loader",exclude:/node_modules/}
    // 配置时不要转化node_modules的包
    // 3.在项目根目录中新建一个.babelrc的Babel配置文件，他属于json语法规范
    // 3.1在babelrc中写如下配置：
    
    // {
    //     test: /\.js$/,
    //     exclude: /(node_modules|bower_components)/,
    //     use: {
    //       loader: 'babel-loader',
    //       options: {
    //         presets: ['@babel/preset-env']
    //       }
    //     }
    //   }


    /* "devDependencies": {
    "@babel/core": "^7.8.6",
    "@babel/plugin-proposal-class-properties": "^7.8.3",
    "@babel/plugin-transform-runtime": "^7.8.3",
    "@babel/preset-env": "^7.8.6",
    "@babel/runtime": "^7.8.4",
    "babel-loader": "^8.0.6",
    "bootstrap": "^3.3.7",
    "cnpm": "^6.1.1",
    "css-loader": "^3.4.2",
    "file-loader": "^5.1.0",
    "html-webpack-plugin": "^3.2.0",
    "less": "^3.11.1",
    "less-loader": "^5.0.0",
    "node-sass": "^4.13.1",
    "sass-loader": "^8.0.2",
    "style-loader": "^1.1.3",
    "url-loader": "^3.0.0",
    "webpack": "^4.42.0",
    "webpack-cli": "^3.3.11",
    "webpack-dev-server": "^3.10.3"
  } */
